sort -f services.txt > dep.txt
echo "---" >> dep.txt
cat dependencies.txt >> dep.txt
