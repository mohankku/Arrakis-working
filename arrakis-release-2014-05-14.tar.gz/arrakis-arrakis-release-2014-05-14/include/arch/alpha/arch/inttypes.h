#define __LENGTH_8_MOD "hh"
#define __LENGTH_16_MOD "h"
#define __LENGTH_32_MOD
#define __LENGTH_64_MOD "l"
#define __LENGTH_MAX_MOD "ll"
#define __LENGTH_PTR_MOD "l"
